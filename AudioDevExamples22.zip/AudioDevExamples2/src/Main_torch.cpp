/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic startup code for a JUCE application.

  ==============================================================================
*/

#include "JuceHeader.h"
#include "MainComponent.h"

#include <torch/torch.h>
#include <torch/script.h> // One-stop header.
#include <iostream>
#include <iomanip>

#include <iostream>
#include <chrono>

#include <opencv2/core/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/imgproc/types_c.h>
#include <iostream>
#include <time.h>
#include <ostream>

#include "../include/tqdm/tqdm.h"
#include "../include/utils/vision_utils.hpp"

using namespace std;

using namespace std;
//using namespace cv;
using namespace std::chrono;

#define kIMAGE_SIZE 512
#define kIMAGE_SIZE_TORCH 512
#define kCHANNELS 3
#define kTOP_K 3


//==============================================================================
class LoadingSVGApplication  : public JUCEApplication
{
public:
    //==============================================================================
    LoadingSVGApplication() {}

    const String getApplicationName() override       { return ProjectInfo::projectName; }
    const String getApplicationVersion() override    { return ProjectInfo::versionString; }
    bool moreThanOneInstanceAllowed() override       { return true; }

    //==============================================================================
    void initialise (const String& commandLine) override
    {
        // This method is where you should put your application's initialisation code..

        mainWindow.reset (new MainWindow (getApplicationName()));

        
        auto VU=VisionUtils();

        cout << "OpenCV version : " << CV_VERSION << endl;
        cout << "Major version : " << CV_MAJOR_VERSION << endl;
        cout << "Minor version : " << CV_MINOR_VERSION << endl;
        cout << "Subminor version : " << CV_SUBMINOR_VERSION << endl;

        

        // Loading your model
        //     // Loading your model
        const std::string s_model_name = "erfnet_fs.pt";
        auto module = torch::jit::load(s_model_name, torch::kCPU);    
        assert(module != nullptr);
        const std::string s_image_name0 = "file_example_MP4_640_3MG.mp4";
        std::cout << " >>> Loading " << s_image_name0 << std::endl;
        // c10::Device device = torch::kCPU;;
        
        
        time_t start, end;
        long num_frames = 0;
        time(&start);  

        cv::VideoCapture video_reader(s_image_name0);    
        if (!video_reader.isOpened())
        {
            std::cout << "!!! Failed to open file: " << s_image_name0 << std::endl;            
        }

        long frame_h = int(video_reader.get(cv::CAP_PROP_FRAME_HEIGHT));
        long frame_w = int(video_reader.get(cv::CAP_PROP_FRAME_WIDTH));
        long nb_frames = int(video_reader.get(cv::CAP_PROP_FRAME_COUNT));
        cv::VideoWriter videoWriter;

        std::cout << "WIDTH " << frame_w << "\n";
        std::cout << "HEIGHT " << frame_h << "\n";
        std::cout << "nb_frames " << nb_frames << "\n";

        double avgFPS = 1.0;
        cv::Mat frame;    
        
        for (num_frames = 0; num_frames < nb_frames; num_frames++) {
            clock_t start = clock();
            video_reader.read(frame); 
            // std::cout << "frame " << frame << "\n";

            // auto juceImage=VU.toJUCEImage(frame,kIMAGE_SIZE_TORCH, kIMAGE_SIZE_TORCH, kCHANNELS);            

            auto input_tensor=VU.toTensor(frame,frame_w, frame_h, kCHANNELS);
//            std::cout << "input_tensor " << input_tensor<< "\n";
            std::vector<torch::jit::IValue> inputs;
            inputs.push_back(input_tensor);

            torch::Tensor out_tensor = module.forward(inputs).toTensor();
            std::cout << "out_tensor " << out_tensor << "\n";
//            auto resultImg= VU.toOpenCV (out_tensor,frame_w, frame_h,kCHANNELS);

            // cv::imshow("window", resultImg);
//            cv::imshow("window", frame);

//            char key = cv::waitKey(10);
//            if (key == 27) // ESC
//                break;
        }
        
        time(&end);
        // Time elapsed
        double seconds = difftime(end, start);
        cout << "Time taken : " << seconds << " seconds" << endl;
        // Calculate frames per second
        double fps = num_frames / seconds;
        cout << "Estimated frames per second : " << fps << endl;
        
    }

    void shutdown() override
    {
        // Add your application's shutdown code here..

        mainWindow = nullptr; // (deletes our window)
    }

    //==============================================================================
    void systemRequestedQuit() override
    {
        // This is called when the app is being asked to quit: you can ignore this
        // request and let the app carry on running, or call quit() to allow the app to close.
        quit();
    }

    void anotherInstanceStarted (const String& commandLine) override
    {
        // When another instance of the app is launched while this one is running,
        // this method is invoked, and the commandLine parameter tells you what
        // the other instance's command-line arguments were.
    }

    //==============================================================================
    /*
        This class implements the desktop window that contains an instance of
        our MainComponent class.
    */
    class MainWindow    : public DocumentWindow
    {
    public:
        MainWindow (String name)  : DocumentWindow (name,
                                                    Desktop::getInstance().getDefaultLookAndFeel()
                                                                          .findColour (ResizableWindow::backgroundColourId),
                                                    DocumentWindow::allButtons)
        {
            setUsingNativeTitleBar (true);
            setContentOwned (new MainComponent(), true);

           #if JUCE_IOS || JUCE_ANDROID
            setFullScreen (true);
           #else
            setResizable (true, true);
            centreWithSize (getWidth(), getHeight());
           #endif

            setVisible (true);
        }

        void closeButtonPressed() override
        {
            // This is called when the user tries to close this window. Here, we'll just
            // ask the app to quit when this happens, but you can change this to do
            // whatever you need.
            JUCEApplication::getInstance()->systemRequestedQuit();
        }

        /* Note: Be careful if you override any DocumentWindow methods - the base
           class uses a lot of them, so by overriding you might break its functionality.
           It's best to do all your work in your content component instead, but if
           you really have to override any DocumentWindow methods, make sure your
           subclass also calls the superclass's method.
        */

    private:
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainWindow)
    };

private:
    std::unique_ptr<MainWindow> mainWindow;
};

//==============================================================================
// This macro generates the main() routine that launches the app.
START_JUCE_APPLICATION (LoadingSVGApplication)
